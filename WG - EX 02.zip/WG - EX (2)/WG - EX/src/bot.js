// GridBot: orchestrates an arithmetic grid on one market. Places the initial
// ladder of limit orders, and on every fill places the opposite order one rung
// away (buy->sell up, sell->buy down), capturing `spacing * size` per round.
// Includes "standard" risk controls: leverage cap, margin pre-check, and
// out-of-range boundary alerts (with optional auto-stop).
import { buildGrid, seedOrders, replacementFor, isReduceOnly } from './grid.js';

export class GridBot {
  constructor(exchange) {
    this.ex = exchange;
    this.running = false;
    this.config = null;
    this.grid = null;
    this.active = new Map();        // orderId -> {levelIndex, side, price, isClose}
    this._pending = new Set();      // "levelIndex:side" currently being placed (in-flight)
    this.fills = [];                // recent fills (capped)
    this.alerts = [];               // recent alerts (capped)
    this.stats = { buys: 0, sells: 0, completedRungs: 0, gridProfit: 0, volume: 0 };
    this.startBalance = null;
    this.lastPrice = null;
    this.outOfRange = false;
    this._onFill = (f) => this._handleFill(f);
    this._onPrice = (p) => this._handlePrice(p);
  }

  /** @param cfg {marketId, mode, lower, upper, gridCount, sizeBase, leverage, autoStopOutOfRange} */
  async start(cfg) {
    if (this.running) throw new Error('机器人已在运行，请先停止。');
    const market = (await this.ex.getMarkets()).find((m) => m.marketId === Number(cfg.marketId));
    if (!market) throw new Error('找不到该市场 marketId=' + cfg.marketId);

    const leverage = Math.min(Number(cfg.leverage || 3), market.maxLeverage || 50);
    const sizeBase = Math.max(Number(cfg.sizeBase), market.minOrderSize || 0);
    this.config = {
      marketId: market.marketId, displayName: market.displayName,
      mode: cfg.mode || 'neutral',
      lower: Number(cfg.lower), upper: Number(cfg.upper),
      gridCount: Number(cfg.gridCount), sizeBase, leverage,
      autoStopOutOfRange: !(cfg.autoStopOutOfRange === false || cfg.autoStopOutOfRange === 'false'), // 默认开启
      stepSize: market.stepSize, stepPrice: market.stepPrice,
    };
    this.grid = buildGrid({ lower: this.config.lower, upper: this.config.upper, gridCount: this.config.gridCount });

    // ---- standard risk pre-check ----
    const mid = (this.config.lower + this.config.upper) / 2;
    const notional = this.grid.count * sizeBase * mid;
    const requiredMargin = notional / leverage;
    // Per-rung economics, NET of fees. feeRate is the max fee signed into orders
    // (both legs of a round-trip pay it). A grid whose spacing can't even cover
    // two fees is structurally loss-making, so we refuse to start it.
    const feeRate = Number(this.ex.feeRate) || 0;
    const grossPerRung = this.grid.spacing * sizeBase;
    const feePerRung = 2 * feeRate * mid * sizeBase;
    const netPerRung = grossPerRung - feePerRung;
    this.risk = {
      leverage, notional: round2(notional), requiredMargin: round2(requiredMargin),
      perRungProfit: round2(grossPerRung),
      perRungFee: round4(feePerRung),
      perRungNet: round4(netPerRung),
      spacingPct: round2((this.grid.spacing / mid) * 100),
      availableBalance: typeof this.ex.balance === 'number' ? round2(this.ex.balance) : null,
    };

    // Block structurally unprofitable grids (spacing too tight vs. fees).
    if (netPerRung <= 0) {
      const minSpacing = round2((2 * feeRate * mid) * 1.5); // suggest 50% headroom over breakeven
      throw new Error(`网格间距过小：每格毛利 ${round4(grossPerRung)} 抵不过两腿手续费 ${round4(feePerRung)}，会净亏。请减少格数或扩大区间，使间距至少约 ${minSpacing}（≈${round2((minSpacing / mid) * 100)}%）。`);
    }
    // Block if we clearly can't fund the grid (margin pre-check now actually checks balance).
    if (typeof this.ex.balance === 'number' && this.ex.balance > 0 && requiredMargin > this.ex.balance) {
      throw new Error(`保证金不足：该网格约需 ${round2(requiredMargin)}（名义 ${round2(notional)} / ${leverage}x），当前可用余额仅 ${round2(this.ex.balance)}。请降低每格数量、减少格数或提高杠杆。`);
    }

    await this.ex.setLeverage(market.marketId, leverage).catch(() => {});
    await this.ex.cancelAll(market.marketId).catch(() => {});

    this.lastPrice = await this.ex.getPrice(market.marketId);
    this.outOfRange = this.lastPrice < this.config.lower || this.lastPrice > this.config.upper;

    this.ex.on('fill', this._onFill);
    this.ex.on('price', this._onPrice);
    if (typeof this.ex.start === 'function') this.ex.start();

    // Mark running BEFORE seeding so a seed order that fills instantly isn't
    // dropped by _handleFill's running-guard (it would otherwise miss a fill).
    if (this.startBalance == null && typeof this.ex.balance === 'number') this.startBalance = this.ex.balance;
    this.running = true;

    // ---- seed the ladder (seeds are OPENING orders: isClose=false) ----
    const seeds = seedOrders({ levels: this.grid.levels, price: this.lastPrice, mode: this.config.mode, spacing: this.grid.spacing });
    for (const s of seeds) await this._place({ ...s, isClose: false });
    this._alert(`已启动 ${this.config.displayName} ${labelMode(this.config.mode)}，${this.grid.count} 格，间距 ${this.grid.spacing}（${this.risk.spacingPct}%），杠杆 ${leverage}x，挂出 ${this.active.size} 单。`);
    return this.getState();
  }

  async stop({ closePosition = false } = {}) {
    if (!this.running) return this.getState();
    this.ex.off('fill', this._onFill);
    this.ex.off('price', this._onPrice);
    this.running = false; // stop reacting to fills before we cancel/close
    await this.ex.cancelAll(this.config.marketId).catch(() => {});
    this.active.clear();
    this._pending.clear();
    let closed = false;
    if (closePosition && typeof this.ex.closePosition === 'function') {
      // closePosition now verifies the position is actually flat (returns bool).
      closed = await this.ex.closePosition(this.config.marketId)
        .then((ok) => ok !== false)
        .catch((e) => { this._alert('⚠️ 平仓失败: ' + e.message + '，请到交易所网页端手动平仓！'); return false; });
    }
    this._alert(
      !closePosition ? '机器人已停止，挂单已撤销。'
        : closed ? '机器人已停止：挂单已撤销，持仓已确认平仓。'
        : '机器人已停止，挂单已撤销；但平仓未确认完成，请到交易所核对持仓！'
    );
    return this.getState();
  }

  /** True if a same-side order is already resting or in-flight at this level. */
  _levelHasSide(levelIndex, side) {
    if (this._pending.has(`${levelIndex}:${side}`)) return true;
    for (const o of this.active.values()) if (o.levelIndex === levelIndex && o.side === side) return true;
    return false;
  }

  async _place(o) {
    // Enforce "at most one order per side per level": prevents stacking a
    // replacement on top of a seed (e.g. a sell replacement landing where a seed
    // sell already rests), which would double the intended exposure.
    if (this._levelHasSide(o.levelIndex, o.side)) return;
    const key = `${o.levelIndex}:${o.side}`;
    this._pending.add(key);
    const clientOrderId = Number(`${o.levelIndex}${o.side === 'buy' ? 0 : 1}${Date.now() % 100000}`);
    const r = await this.ex.placeLimitOrder({
      marketId: this.config.marketId, side: o.side, price: o.price,
      sizeBase: this.config.sizeBase, reduceOnly: o.reduceOnly ?? isReduceOnly(o.side, this.config.mode),
      levelIndex: o.levelIndex, clientOrderId,
    }).catch((e) => { this._alert('下单失败: ' + e.message); return null; });
    this._pending.delete(key);
    if (r?.orderId) this.active.set(r.orderId, { levelIndex: o.levelIndex, side: o.side, price: o.price, isClose: !!o.isClose });
  }

  _handleFill(f) {
    if (!this.running || f.marketId !== this.config.marketId) return;
    const meta = this.active.get(f.orderId);
    this.active.delete(f.orderId);
    if (f.side === 'buy') this.stats.buys++; else this.stats.sells++;
    this.stats.volume = round2(this.stats.volume + f.price * f.sizeBase); // 累计成交额(名义)
    this.fills.unshift({ t: Date.now(), side: f.side, price: f.price, size: f.sizeBase, level: f.levelIndex });
    if (this.fills.length > 50) this.fills.pop();

    // A rung is COMPLETED only when a CLOSING order (a replacement we placed)
    // fills — not when an opening seed fills. Relying on side alone overcounted
    // (e.g. neutral-mode seed sells above price are opens, not closes).
    if (meta?.isClose) {
      this.stats.completedRungs++;
      this.stats.gridProfit = round2(this.stats.completedRungs * (this.risk?.perRungNet ?? this.grid.spacing * this.config.sizeBase));
    }

    // Replacements are CLOSING orders (isClose=true): one rung opposite.
    const repl = replacementFor({ side: f.side, levelIndex: f.levelIndex }, this.grid.levels, this.config.mode);
    if (repl && !this.outOfRange) this._place({ ...repl, isClose: true });
  }

  _handlePrice(p) {
    if (p.marketId !== this.config.marketId) return;
    this.lastPrice = p.price;
    const out = p.price < this.config.lower || p.price > this.config.upper;
    if (out && !this.outOfRange) {
      this.outOfRange = true;
      const where = p.price < this.config.lower ? '跌破下边界' : '突破上边界';
      this._alert(`⚠️ 价格${where}（${round2(p.price)}），已暂停在区间外补单。` + (this.config.autoStopOutOfRange ? ' 触发自动停止：撤销挂单并市价平仓。' : ' 请关注单边趋势风险。'));
      if (this.config.autoStopOutOfRange) this.stop({ closePosition: true });
    } else if (!out && this.outOfRange) {
      this.outOfRange = false;
      this._alert(`价格回到区间内（${round2(p.price)}），恢复正常网格运行，补齐缺失档位。`);
      this._reseed(p.price); // refill ladder gaps left by the excursion
    }
  }

  /** Re-place any missing OPENING orders for the current price (gap recovery). */
  _reseed(price) {
    if (!this.running || this.outOfRange) return;
    const seeds = seedOrders({ levels: this.grid.levels, price, mode: this.config.mode, spacing: this.grid.spacing });
    for (const s of seeds) {
      if (!this._levelHasSide(s.levelIndex, s.side)) this._place({ ...s, isClose: false });
    }
  }

  _alert(message) {
    this.alerts.unshift({ t: Date.now(), message });
    if (this.alerts.length > 30) this.alerts.pop();
  }

  getState() {
    const pos = this.running || this.config ? this.ex.getPosition?.(this.config?.marketId) : null;
    const realized = typeof this.ex.realizedPnl === 'number' ? round2(this.ex.realizedPnl) : this.stats.gridProfit;
    const openByLevel = {};
    for (const o of this.active.values()) openByLevel[o.levelIndex] = o.side;
    const unrealized = pos ? round2(pos.unrealizedPnl) : 0;
    const balance = typeof this.ex.balance === 'number' ? round2(this.ex.balance) : null;
    const totalPnl = round2(realized + unrealized);
    const equity = balance != null ? round2(balance + unrealized) : null;
    const returnPct = (equity && equity > 0) ? round2((totalPnl / equity) * 100) : null; // 按当前权益计算
    return {
      mode: this.ex.mode,
      running: this.running,
      config: this.config,
      grid: this.grid,
      lastPrice: this.lastPrice != null ? round2(this.lastPrice) : null,
      outOfRange: this.outOfRange,
      risk: this.risk,
      stats: this.stats,
      openOrders: this.active.size,
      openByLevel,
      position: pos ? { sizeBase: round6(pos.sizeBase), entryPrice: round2(pos.entryPrice), unrealizedPnl: round2(pos.unrealizedPnl), leverage: pos.leverage ?? null } : null,
      realizedPnl: realized,
      unrealizedPnl: unrealized,
      totalPnl,
      returnPct,
      equity,
      balance,
      volume: this.stats.volume,
      startBalance: this.startBalance != null ? round2(this.startBalance) : null,
      fills: this.fills.slice(0, 20),
      alerts: this.alerts.slice(0, 12),
    };
  }
}

function labelMode(m) { return m === 'long' ? '做多网格' : m === 'short' ? '做空网格' : '中性网格'; }
function round2(x) { return Math.round(x * 100) / 100; }
function round4(x) { return Math.round(x * 1e4) / 1e4; }
function round6(x) { return Math.round(x * 1e6) / 1e6; }
