// Zero-dependency HTTP + SSE server (Node built-ins only; undici only needed
// when using a proxy). Serves the dashboard, a small REST API, and pushes
// live bot state to the browser via Server-Sent Events.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { getConfig, ROOT } from './config.js';
import { createExchange } from './exchange/index.js';
import { GridBot } from './bot.js';
import { analyzeTrend } from './trend.js';
import { setupProxy } from './proxy.js';


const cfg = getConfig();
const proxyUsed = await setupProxy(); // after getConfig() so .env EXTENDED_PROXY is loaded
if (proxyUsed) console.log('[代理] 已启用: ' + proxyUsed);
else console.log('[代理] 未配置（程序将直连，国内可能连不上交易所）');
const exchange = createExchange(cfg);
const bot = new GridBot(exchange);
const clients = new Set();

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };

function send(res, code, obj) {
  // stringify BEFORE writeHead so a serialization error can't leave the
  // response half-written (and never crash on an already-sent response)
  const body = JSON.stringify(obj, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));
  if (res.headersSent) { try { res.end(); } catch { /* ignore */ } return; }
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve) => {
    let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); } });
  });
}

// Guard against DNS-rebinding / cross-site requests to the (unauthenticated)
// trade API: only accept requests whose Host header is loopback, and reject any
// cross-origin request. The dashboard itself is same-origin so it's unaffected.
function isLocalRequest(req) {
  const host = String(req.headers.host || '').toLowerCase();
  const hostname = host.split(':')[0];
  const hostOk = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]' || hostname === '::1';
  const origin = req.headers.origin;
  if (origin) {
    try { const oh = new URL(origin).hostname; if (!(oh === 'localhost' || oh === '127.0.0.1' || oh === '::1')) return false; }
    catch { return false; }
  }
  return hostOk;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  try {
    // state-changing trade endpoints must originate locally
    if ((p === '/api/start' || p === '/api/stop') && !isLocalRequest(req)) {
      return send(res, 403, { error: '已拒绝非本机请求（出于资金安全，下单接口仅允许本机访问）。' });
    }
    if (p === '/api/markets') return send(res, 200, {
      mode: 'live',
      dataSource: exchange.dataSource || 'real',
      network: exchange.network || cfg.network,
      apiUrl: exchange.apiUrl || cfg.apiUrl,
      markets: await exchange.getMarkets(),
    });

    if (p === '/api/trend') {
      const marketId = Number(url.searchParams.get('marketId') || 1);
      const intervalSec = Number(url.searchParams.get('intervalSec') || 3600);
      let candles = [];
      try { candles = await exchange.getCandles(marketId, intervalSec, 200); } catch (e) { /* tolerate */ }
      let price = null; try { price = await exchange.getPrice(marketId); } catch {}
      const analysis = (candles && candles.length >= 20)
        ? analyzeTrend(candles)
        : { trend: 'range', recommended: 'neutral', strength: 0, atrPct: null, price,
            detail: '暂时拿不到足够K线数据，已默认中性网格。可手动设置上下边界后启动；不影响下单。' };
      return send(res, 200, { analysis, candles: (candles || []).slice(-120) });
    }

    if (p === '/api/state') return send(res, 200, bot.getState());

    if (p === '/api/start' && req.method === 'POST') {
      try { return send(res, 200, await bot.start(await readBody(req))); }
      catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (p === '/api/stop' && req.method === 'POST') {
      try { return send(res, 200, await bot.stop(await readBody(req))); }
      catch (e) { return send(res, 400, { error: e.message }); }
    }

    if (p === '/api/stream') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      res.write(`data: ${JSON.stringify(bot.getState())}\n\n`);
      clients.add(res);
      req.on('close', () => clients.delete(res));
      return;
    }

    let file = p === '/' ? '/index.html' : p;
    const full = path.join(ROOT, 'public', path.normalize(file).replace(/^(\.\.[/\\])+/, ''));
    if (fs.existsSync(full) && fs.statSync(full).isFile()) {
      res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream' });
      return fs.createReadStream(full).pipe(res);
    }
    send(res, 404, { error: 'not found' });
  } catch (e) { send(res, 500, { error: e.message }); }
});

setInterval(() => {
  const data = `data: ${JSON.stringify(bot.getState())}\n\n`;
  for (const res of clients) { try { res.write(data); } catch { clients.delete(res); } }
}, 1000);

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\n[启动失败] 端口 ${cfg.port} 已被占用——很可能之前那个程序窗口还在运行。`);
    console.error('请先关闭之前的黑色命令行窗口（或在里面按 Ctrl+C），再启动本程序。');
    console.error('或在 .env 里改 PORT=8082 用别的端口。\n');
  } else {
    console.error('[服务器错误] ' + (e?.message || e));
  }
  process.exit(1);
});

try {
  await exchange.init();
} catch (e) {
  const cause = e?.cause || {};
  const code = cause.code || '';
  const addr = cause.address ? `${cause.address}:${cause.port ?? ''}` : '';
  console.error('\n[启动失败] 无法连接 Extended 接口：' + (e?.message || e));
  console.error('  目标接口: ' + (cfg.apiUrl) + '   网络: ' + cfg.network);
  console.error('  代理: ' + (proxyUsed || '未启用'));
  if (code || addr) console.error('  底层错误: ' + code + (addr ? ('  地址 ' + addr) : '') + (cause.message ? ('  ' + cause.message) : ''));
  console.error('');
  // interpret common causes
  if (code === 'ENOTFOUND') {
    console.error('  ➤ 域名解析失败：检查网络连接，或在 .env 配置 EXTENDED_PROXY 走代理。');
  } else if (code === 'ECONNREFUSED' && (addr.includes('127.0.0.1') || addr.includes('localhost'))) {
    console.error('  ➤ 连不上你本机代理端口：八成是 .env 里 EXTENDED_PROXY 端口填错了。');
    console.error('    打开你的代理软件查"HTTP 代理端口"，把 .env 的 EXTENDED_PROXY 改成 http://127.0.0.1:该端口。');
  } else if (code === 'UND_ERR_CONNECT_TIMEOUT' || /timeout/i.test(cause.message || '')) {
    console.error('  ➤ 连接超时：接口被网络拦截，或代理没能转发到该接口。');
    console.error('    确认代理已开启且 EXTENDED_PROXY 端口正确。');
  } else {
    console.error('  ➤ 排查：确认 .env 的 EXTENDED_API_URL 可访问，且 API key 等凭据填写正确。');
  }
  console.error('');
  process.exit(1);
}
server.listen(cfg.port, cfg.host, () => {
  console.log('\nExtended 网格机器人已启动 [实盘 LIVE]');
  console.log(`仪表盘: http://localhost:${cfg.port}  (绑定 ${cfg.host})`);
  console.log(`行情数据源: 实时 (${exchange.network}) ${exchange.apiUrl || ''}`);
  console.log('⚠️ 实盘模式：将使用真实资金在 Extended 主网下单。\n');
});
