// Lightweight assertions for grid math, trend detection, stark signing, and a
// GridBot run against a mock exchange.
import assert from 'node:assert';
import { EventEmitter } from 'node:events';
import { buildGrid, seedOrders, replacementFor } from '../src/grid.js';
import { analyzeTrend } from '../src/trend.js';
import { GridBot } from '../src/bot.js';
import {
  selfTest, settlementAmounts, orderMsgHash, starkSign, alignToStep,
} from '../src/exchange/starkcrypto.js';

// Minimal in-memory exchange implementing the IExchange contract, enough to
// drive GridBot deterministically (no network, no real money).
class MockExchange extends EventEmitter {
  constructor() { super(); this.mode = 'live'; this.balance = 10000; this.realizedPnl = 0; this._id = 1; this.placed = []; }
  async init() { return true; }
  async getMarkets() {
    return [{ marketId: 1, displayName: 'BTC-USD', symbol: 'BTC', lastPrice: 100,
      stepSize: 0.0001, stepPrice: 0.01, maxLeverage: 50, minOrderSize: 0.001 }];
  }
  async getPrice() { return 100; }
  async setLeverage() { return true; }
  async cancelAll() { return true; }
  async placeLimitOrder(o) { const orderId = String(this._id++); this.placed.push({ orderId, ...o }); return { orderId }; }
  getPosition() { return null; }
  start() {} stop() {}
  /** test helper: simulate an exchange-side fill of a previously placed order */
  fill(order) {
    this.emit('fill', { orderId: order.orderId, marketId: order.marketId, side: order.side,
      price: order.price, sizeBase: order.sizeBase, levelIndex: order.levelIndex });
  }
}

let passed = 0;
const ok = (name) => { console.log('  ok -', name); passed++; };

// --- stark signing vs the official Extended python SDK test vectors ---
assert.equal(selfTest(), true);
ok('starkcrypto selfTest (official SDK SELL vector: amounts + SNIP-12 hash + signature)');

{ // BUY vector from tests/signing/order_object/test_limit_order_object.py
  const a = settlementAmounts({
    qty: '0.00100000', price: '43445.11680000', feeRate: '0.0005',
    synRes: 1000000, colRes: 1000000, isBuy: true,
  });
  assert.equal(a.syntheticAmount, 1000n);
  assert.equal(a.collateralAmount, -43445117n);
  assert.equal(a.feeAmount, 21723n);
  const h = orderMsgHash({
    positionId: 10002,
    baseAssetId: 0x4254432d3600000000000000000000n,
    baseAmount: a.syntheticAmount,
    quoteAssetId: 0x31857064564ed0ff978e687456963cba09c2c6985d8f9300a1de4962fafa054n,
    quoteAmount: a.collateralAmount,
    feeAssetId: 0x31857064564ed0ff978e687456963cba09c2c6985d8f9300a1de4962fafa054n,
    feeAmount: a.feeAmount,
    expirationSec: 1706836137, salt: 1473459052,
    publicKey: 0x61c5e7e8339b7d56f197f54ea91b776776690e3232313de0f2ecbd0ef76f466n,
    domain: { name: 'Perpetuals', version: 'v0', chainId: 'SN_SEPOLIA', revision: 1 },
  });
  assert.equal(h, 2495374044666992118771096772295242242651427695217815113349321039194683172848n);
  const { r, s } = starkSign(h, 0x7a7ff6fd3cab02ccdcd4a572563f5976f8976899b03a39773795a3c486d4986n);
  assert.equal(r, 0xa55625c7d5f1b85bed22556fc805224b8363074979cf918091d9ddb1403e13n);
  assert.equal(s, 0x504caf634d859e643569743642ccf244434322859b2421d76f853af43ae7a46n);
  ok('starkcrypto BUY vector: amounts + SNIP-12 hash + deterministic signature');
}

assert.equal(alignToStep(61827.7345, '0.1'), '61827.7');
assert.equal(alignToStep(0.0012345, '0.00001', 'down'), '0.00123');
assert.equal(alignToStep(74007, '1'), '74007');
ok('alignToStep: price/qty snap to market steps');

// --- buildGrid ---
const g = buildGrid({ lower: 100, upper: 200, gridCount: 10 });
assert.equal(g.levels.length, 11);
assert.equal(g.spacing, 10);
assert.equal(g.levels[0], 100);
assert.equal(g.levels[10], 200);
ok('buildGrid: 10 cells -> 11 levels, spacing 10');

// --- seedOrders neutral ---
const neutral = seedOrders({ levels: g.levels, price: 150, mode: 'neutral', spacing: 10 });
assert.ok(neutral.every((o) => (o.price < 150 ? o.side === 'buy' : o.side === 'sell')));
assert.ok(neutral.some((o) => o.side === 'buy') && neutral.some((o) => o.side === 'sell'));
ok('seedOrders neutral: buys below, sells above');

// --- seedOrders long: buys only ---
const long = seedOrders({ levels: g.levels, price: 150, mode: 'long', spacing: 10 });
assert.ok(long.every((o) => o.side === 'buy'));
ok('seedOrders long: buys only, below price');

// --- seedOrders short: sells only ---
const short = seedOrders({ levels: g.levels, price: 150, mode: 'short', spacing: 10 });
assert.ok(short.every((o) => o.side === 'sell'));
ok('seedOrders short: sells only, above price');

// --- replacement rules ---
const r1 = replacementFor({ side: 'buy', levelIndex: 4 }, g.levels, 'neutral');
assert.equal(r1.side, 'sell'); assert.equal(r1.levelIndex, 5);
const r2 = replacementFor({ side: 'sell', levelIndex: 4 }, g.levels, 'neutral');
assert.equal(r2.side, 'buy'); assert.equal(r2.levelIndex, 3);
assert.equal(replacementFor({ side: 'buy', levelIndex: 10 }, g.levels, 'neutral'), null);
ok('replacementFor: buy->sell up, sell->buy down, edges null');

// --- trend detection: synthetic uptrend ---
const upCandles = [];
let p = 100;
for (let i = 0; i < 120; i++) { p *= 1.004; upCandles.push({ time: i, open: p, high: p * 1.001, low: p * 0.999, close: p, volume: 1 }); }
const upA = analyzeTrend(upCandles);
assert.equal(upA.trend, 'up'); assert.equal(upA.recommended, 'long');
ok('analyzeTrend: rising series -> up / long');

const downCandles = [];
p = 100;
for (let i = 0; i < 120; i++) { p *= 0.996; downCandles.push({ time: i, open: p, high: p * 1.001, low: p * 0.999, close: p, volume: 1 }); }
const downA = analyzeTrend(downCandles);
assert.equal(downA.trend, 'down'); assert.equal(downA.recommended, 'short');
ok('analyzeTrend: falling series -> down / short');

const flatCandles = [];
for (let i = 0; i < 120; i++) { const x = 100 + Math.sin(i / 5) * 0.5; flatCandles.push({ time: i, open: x, high: x + 0.2, low: x - 0.2, close: x, volume: 1 }); }
const flatA = analyzeTrend(flatCandles);
assert.equal(flatA.recommended, 'neutral');
ok('analyzeTrend: flat series -> neutral');

// --- integration: GridBot seeds a ladder and re-quotes on fills (mock exchange) ---
const ex = new MockExchange();
await ex.init();
const bot = new GridBot(ex);
await bot.start({ marketId: 1, mode: 'neutral', lower: 90, upper: 110, gridCount: 20, sizeBase: 0.01, leverage: 3 });
let st = bot.getState();
assert.ok(st.openOrders > 0, 'expected seeded ladder');
assert.ok(st.risk.requiredMargin > 0);

// a buy fill should bump the buy count and place the opposite (sell) replacement one rung up
const before = ex.placed.length;
const aBuy = ex.placed.find((o) => o.side === 'buy');
assert.ok(aBuy, 'expected at least one resting buy');
ex.fill(aBuy);
await new Promise((r) => setTimeout(r, 20)); // let async _place settle
st = bot.getState();
assert.ok(st.stats.buys >= 1, 'buy fill counted');
assert.ok(ex.placed.length > before, 'replacement order placed after fill');
await bot.stop();
ok(`integration mock run: ${st.stats.buys} buy(s) filled, replacement re-quoted (${ex.placed.length} total orders placed)`);

console.log(`\nAll ${passed} checks passed.`);
