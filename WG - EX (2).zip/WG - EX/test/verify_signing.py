# Pure-python verification of Extended (Starknet perpetuals) order hashing & signing
# against official x10 python SDK test vectors.
import hashlib, hmac, math
from decimal import Decimal, Context, ROUND_DOWN, ROUND_UP

P = 2**251 + 17 * 2**192 + 1  # stark field prime
EC_ORDER = 0x0800000000000010FFFFFFFFFFFFFFFFB781126DCAE7B2321E66A241ADC64D2F
ALPHA = 1
BETA = 0x6F21413EFBE40DE150E596D72F7A8C5609AD26C15C915C1F4CDFCB99CEE9E89
EC_GEN = (0x1EF15C18599971B7BECED415A40F0C7DEACFD9B0D1819E03D723D8BC943CFCA,
          0x5668060AA49730B7BE4801DF46EC62DE53ECD11ABE43A32873000C36E8DC1F)

# ---------- keccak256 ----------
def keccak256(data: bytes) -> bytes:
    RC = [0x0000000000000001,0x0000000000008082,0x800000000000808A,0x8000000080008000,
          0x000000000000808B,0x0000000080000001,0x8000000080008081,0x8000000000008009,
          0x000000000000008A,0x0000000000000088,0x0000000080008009,0x000000008000000A,
          0x000000008000808B,0x800000000000008B,0x8000000000008089,0x8000000000008003,
          0x8000000000008002,0x8000000000000080,0x000000000000800A,0x800000008000000A,
          0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008]
    ROT = [[0,36,3,41,18],[1,44,10,45,2],[62,6,43,15,61],[28,55,25,21,56],[27,20,39,8,14]]
    M = 0xFFFFFFFFFFFFFFFF
    def rol(x,n): n%=64; return ((x<<n)|(x>>(64-n)))&M if n else x
    def f(A):
        for rc in RC:
            C=[A[x][0]^A[x][1]^A[x][2]^A[x][3]^A[x][4] for x in range(5)]
            D=[C[(x-1)%5]^rol(C[(x+1)%5],1) for x in range(5)]
            A=[[A[x][y]^D[x] for y in range(5)] for x in range(5)]
            B=[[0]*5 for _ in range(5)]
            for x in range(5):
                for y in range(5):
                    B[y][(2*x+3*y)%5]=rol(A[x][y],ROT[x][y])
            A=[[B[x][y]^((~B[(x+1)%5][y])&B[(x+2)%5][y]&M) for y in range(5)] for x in range(5)]
            A[0][0]^=rc
        return A
    rate=136
    Pd=bytearray(data); Pd.append(0x01)
    while len(Pd)%rate: Pd.append(0)
    Pd[-1]^=0x80
    A=[[0]*5 for _ in range(5)]
    for off in range(0,len(Pd),rate):
        for i in range(rate//8):
            x,y=i%5,i//5
            A[x][y]^=int.from_bytes(Pd[off+8*i:off+8*i+8],'little')
        A=f(A)
    out=bytearray()
    for i in range(4):
        x,y=i%5,i//5
        out+=A[x][y].to_bytes(8,'little')
    return bytes(out)

assert keccak256(b'').hex() == 'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470', 'keccak self-test failed'

def selector(s: str) -> int:
    return int.from_bytes(keccak256(s.encode()), 'big') & (2**250 - 1)

# verify ORDER_TYPE_HASH from cairo source
ORDER_TYPE_STR = '"Order"("position_id":"felt","base_asset_id":"AssetId","base_amount":"i64","quote_asset_id":"AssetId","quote_amount":"i64","fee_asset_id":"AssetId","fee_amount":"u64","expiration":"Timestamp","salt":"felt")"PositionId"("value":"u32")"AssetId"("value":"felt")"Timestamp"("seconds":"u64")'
ORDER_TYPE_HASH = selector(ORDER_TYPE_STR)
print('ORDER_TYPE_HASH', hex(ORDER_TYPE_HASH))
assert ORDER_TYPE_HASH == 0x36da8d51815527cabfaa9c982f564c80fa7429616739306036f1f9b608dd112, 'order type hash mismatch'

DOMAIN_TYPE_STR = '"StarknetDomain"("name":"shortstring","version":"shortstring","chainId":"shortstring","revision":"shortstring")'
DOMAIN_TYPE_HASH = selector(DOMAIN_TYPE_STR)
print('DOMAIN_TYPE_HASH', hex(DOMAIN_TYPE_HASH))

# ---------- poseidon ----------
def _round_constants():
    return [[int(hashlib.sha256(f'Hades{3*i+j}'.encode()).hexdigest(),16) % P for j in range(3)] for i in range(91)]
ARK = _round_constants()

def hades(state):
    s0,s1,s2 = state
    idx=0
    for r in range(91):
        a0,a1,a2 = ARK[r]
        s0=(s0+a0)%P; s1=(s1+a1)%P; s2=(s2+a2)%P
        if r<4 or r>=87:
            s0=pow(s0,3,P); s1=pow(s1,3,P); s2=pow(s2,3,P)
        else:
            s2=pow(s2,3,P)
        t0=(3*s0+s1+s2)%P
        t1=(s0-s1+s2)%P
        t2=(s0+s1-2*s2)%P
        s0,s1,s2=t0,t1,t2
    return [s0,s1,s2]

def poseidon_hash_many(vals):
    v=list(vals)+[1]
    if len(v)%2: v.append(0)
    st=[0,0,0]
    for i in range(0,len(v),2):
        st=hades([(st[0]+v[i])%P,(st[1]+v[i+1])%P,st[2]])
    return st[0]

def ss(s: str) -> int:  # cairo short string
    return int.from_bytes(s.encode(),'big')

# ---------- stark curve ecdsa ----------
def inv_mod(a,m): return pow(a,-1,m)
def ec_add(p1,p2):
    if p1 is None: return p2
    if p2 is None: return p1
    if p1[0]==p2[0]:
        if (p1[1]+p2[1])%P==0: return None
        m=(3*p1[0]*p1[0]+ALPHA)*inv_mod(2*p1[1],P)%P
    else:
        m=(p1[1]-p2[1])*inv_mod(p1[0]-p2[0],P)%P
    x=(m*m-p1[0]-p2[0])%P
    return (x,(m*(p1[0]-x)-p1[1])%P)
def ec_mult(k,pt):
    res=None
    while k:
        if k&1: res=ec_add(res,pt)
        pt=ec_add(pt,pt)
        k>>=1
    return res

def _bits2int(b: bytes, qlen: int) -> int:
    x=int.from_bytes(b,'big')
    blen=len(b)*8
    return x >> (blen-qlen) if blen>qlen else x

def generate_k_rfc6979(msg_hash: int, priv: int, seed=None) -> int:
    # mirror starkware signature.py
    if 1 <= msg_hash.bit_length() % 8 <= 4 and msg_hash.bit_length() >= 248:
        msg_hash *= 16
    extra = b'' if seed is None else seed.to_bytes(max(1,math.ceil(seed.bit_length()/8)),'big')
    data = msg_hash.to_bytes(math.ceil(msg_hash.bit_length()/8),'big')
    q=EC_ORDER; qlen=q.bit_length(); rolen=(qlen+7)//8
    def int2octets(x): return x.to_bytes(rolen,'big')
    def bits2octets(b):
        z1=_bits2int(b,qlen); z2=z1%q
        return int2octets(z2)
    V=b'\x01'*32; K=b'\x00'*32
    K=hmac.new(K,V+b'\x00'+int2octets(priv)+bits2octets(data)+extra,hashlib.sha256).digest()
    V=hmac.new(K,V,hashlib.sha256).digest()
    K=hmac.new(K,V+b'\x01'+int2octets(priv)+bits2octets(data)+extra,hashlib.sha256).digest()
    V=hmac.new(K,V,hashlib.sha256).digest()
    while True:
        T=b''
        while len(T)<rolen:
            V=hmac.new(K,V,hashlib.sha256).digest()
            T+=V
        k=_bits2int(T,qlen)
        if 1<=k<q: return k
        K=hmac.new(K,V+b'\x00',hashlib.sha256).digest()
        V=hmac.new(K,V,hashlib.sha256).digest()

def stark_sign(msg_hash: int, priv: int):
    assert 0<=msg_hash<2**251
    seed=None
    while True:
        k=generate_k_rfc6979(msg_hash,priv,seed)
        seed = 1 if seed is None else seed+1
        x=ec_mult(k,EC_GEN)[0]
        r=int(x)
        if not (1<=r<2**251): continue
        if (msg_hash+r*priv)%EC_ORDER==0: continue
        w=k*inv_mod(msg_hash+r*priv,EC_ORDER)%EC_ORDER
        if not (1<=w<2**251): continue
        s=inv_mod(w,EC_ORDER)
        return r,s

# ---------- order hash construction ----------
def to_felt(v: int) -> int:
    return v % P

def order_msg_hash(*, position_id, base_asset_id, base_amount, quote_asset_id, quote_amount,
                   fee_asset_id, fee_amount, expiration_sec, salt, public_key,
                   dom_name, dom_version, dom_chain, dom_revision):
    struct_hash = poseidon_hash_many([
        ORDER_TYPE_HASH,
        position_id,
        base_asset_id,
        to_felt(base_amount),
        quote_asset_id,
        to_felt(quote_amount),
        fee_asset_id,
        fee_amount,
        expiration_sec,
        salt,
    ])
    domain_hash = poseidon_hash_many([
        DOMAIN_TYPE_HASH, ss(dom_name), ss(dom_version), ss(dom_chain), dom_revision,
    ])
    return poseidon_hash_many([ss('StarkNet Message'), domain_hash, public_key, struct_hash])

# ---------- amounts (mirror SDK) ----------
CTX_DOWN=Context(rounding=ROUND_DOWN); CTX_UP=Context(rounding=ROUND_UP)
def to_stark(value: Decimal, resolution: int, ctx: Context) -> int:
    return int(ctx.multiply(value, Decimal(resolution)).to_integral(context=ctx))

# ---------- test vectors (official SDK, testnet domain) ----------
PRIV=0x7a7ff6fd3cab02ccdcd4a572563f5976f8976899b03a39773795a3c486d4986
PUB =0x61c5e7e8339b7d56f197f54ea91b776776690e3232313de0f2ecbd0ef76f466
VAULT=10002
SYN_ID=0x4254432d3600000000000000000000
COL_ID=0x31857064564ed0ff978e687456963cba09c2c6985d8f9300a1de4962fafa054
RES=1_000_000
NONCE=1473459052
QTY=Decimal('0.00100000'); PRICE=Decimal('43445.11680000'); FEE=Decimal('0.0005')
# frozen time 2024-01-05 01:08:56.860694 UTC; expire=+14d; settlement exp=+14d buffer
EXPIRE_TS=1705626536.860694  # = expiryEpochMillis/1000 from the vector
EXP_SEC=math.ceil(EXPIRE_TS+14*86400)
print('settlement expiration:', EXP_SEC)

def build(side):
    is_buy = side=='BUY'
    ctx = CTX_UP if is_buy else CTX_DOWN
    syn = to_stark(QTY, RES, ctx)
    col = to_stark(ctx.multiply(QTY,PRICE), RES, ctx)
    fee = to_stark(CTX_UP.multiply(FEE, CTX_UP.multiply(QTY,PRICE)), RES, CTX_UP)
    if is_buy: col=-col
    else: syn=-syn
    return syn,col,fee

for side, exp_id, exp_r, exp_s, exp_amounts in [
    ('SELL',
     2969335148777495210033041829700798003994871688044444919524700744667647811801,
     0x604ef07147d4251385eaaa630e6a71db8f0a8c7cb33021c98698047db80edfa,
     0x6c707d9a06604d3f8ffd34378bf4fce7c0aaf50cba4cf37c3525c323106cda5,
     (-1000, 43445116, 21723)),
    ('BUY',
     2495374044666992118771096772295242242651427695217815113349321039194683172848,
     0xa55625c7d5f1b85bed22556fc805224b8363074979cf918091d9ddb1403e13,
     0x504caf634d859e643569743642ccf244434322859b2421d76f853af43ae7a46,
     (1000, -43445117, 21723)),
]:
    syn,col,fee = build(side)
    assert (syn,col,fee)==exp_amounts, f'{side} amounts {syn},{col},{fee} != {exp_amounts}'
    h = order_msg_hash(position_id=VAULT, base_asset_id=SYN_ID, base_amount=syn,
                       quote_asset_id=COL_ID, quote_amount=col, fee_asset_id=COL_ID,
                       fee_amount=fee, expiration_sec=EXP_SEC, salt=NONCE, public_key=PUB,
                       dom_name='Perpetuals', dom_version='v0', dom_chain='SN_SEPOLIA', dom_revision=1)
    print(side, 'hash', h, 'expected', exp_id, 'MATCH' if h==exp_id else 'FAIL')
    assert h==exp_id, f'{side} hash mismatch'
    r,s = stark_sign(h, PRIV)
    print(side, 'r', hex(r), 'MATCH' if r==exp_r else 'FAIL')
    print(side, 's', hex(s), 'MATCH' if s==exp_s else 'FAIL')
    assert r==exp_r and s==exp_s, f'{side} signature mismatch'

