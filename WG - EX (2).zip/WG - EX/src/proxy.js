// Routes all Node fetch() through an HTTP proxy when configured — for users
// who reach the exchange via a proxy/VPN. The browser may use a proxy
// automatically, but Node connects directly by default, so without this it
// times out. Requires `undici` (installed via `npm install`); everything else
// in this project runs with zero dependencies.
export async function setupProxy() {
  const proxy = process.env.EXTENDED_PROXY || process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
  if (!proxy) return null;
  try {
    const { ProxyAgent, setGlobalDispatcher } = await import('undici');
    setGlobalDispatcher(new ProxyAgent(proxy));
    return proxy;
  } catch (e) {
    console.error('⚠ 已配置代理 ' + proxy + ' 但未能加载 undici，请先运行 npm install。错误：' + e.message);
    return null;
  }
}
